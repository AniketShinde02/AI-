"use client";

import { Globe, FileText, Code2, FolderSync, Mic, Settings, ScanEye, PenTool, Plus } from "lucide-react";
import { ShadowButton } from "@/components/nexus-x/ShadowButton";
import { ShadowDiamond } from "@/components/nexus-x/ShadowDiamond";
import { TechBorder } from "@/components/nexus-x/TechBorder";

export default function NexusXAgents() {
  const agents = [
    { name: "Browser Agent", desc: "Web research & data", icon: Globe, status: "Active" },
    { name: "Research Agent", desc: "Deep research & reports", icon: FileText, status: "Active" },
    { name: "Coding Agent", desc: "Code generation & debug", icon: Code2, status: "Active" },
    { name: "Files Agent", desc: "Local files & documents", icon: FolderSync, status: "Active" },
    { name: "Voice Agent", desc: "Voice commands & control", icon: Mic, status: "Active" },
    { name: "Automation Agent", desc: "Workflows & automation", icon: Settings, status: "Active" },
    { name: "Vision Agent", desc: "Image analysis & OCR", icon: ScanEye, status: "Active" },
    { name: "Custom Agent", desc: "Build your own agent", icon: PenTool, status: "Create" },
  ];

  return (
    <div className="flex-1 flex flex-col max-w-6xl mx-auto w-full h-full pt-4 relative z-10">
      <div className="w-full flex justify-between items-center mb-12">
        <div>
          <h2 className="text-2xl font-quantico font-bold tracking-[0.2em] uppercase text-white mb-2 drop-shadow-md">Agent Deck</h2>
          <p className="text-[10px] text-[#00FFFF] uppercase tracking-widest font-mono">Deploy Specialized Units</p>
        </div>
        <button className="flex items-center gap-2 px-6 py-2 bg-transparent border border-[#00FFFF]/50 hover:bg-[#00FFFF]/10 text-[10px] font-bold text-[#00FFFF] uppercase tracking-[0.2em] transition-all" style={{ clipPath: 'polygon(0 0, 100% 0, 100% calc(100% - 10px), calc(100% - 10px) 100%, 0 100%)' }}>
          <Plus size={14} />
          Create Unit
        </button>
      </div>

      <div className="grid grid-cols-3 gap-8">
        {agents.map((agent) => {
          const Icon = agent.icon;
          return (
            <TechBorder key={agent.name} glowColor={agent.status === 'Active' ? '#00FFFF' : '#52525b'} className="group cursor-pointer">
              <div className="bg-[#06060c]/90 p-8 flex flex-col items-center justify-center text-center transition-all relative overflow-hidden h-full" style={{ clipPath: 'polygon(0 0, 100% 0, 100% calc(100% - 15px), calc(100% - 15px) 100%, 0 100%)' }}>
                <div className="absolute inset-0 bg-gradient-to-b from-[#00FFFF]/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none"></div>
                
                <div className="mb-6 mt-2">
                  <ShadowDiamond active={agent.status === 'Active'} size={64}>
                    <Icon size={24} className={agent.status === 'Active' ? 'text-[#00FFFF]' : 'text-zinc-600'} />
                  </ShadowDiamond>
                </div>
                
                <h3 className="text-sm font-quantico font-bold text-white tracking-widest mb-2 uppercase">{agent.name}</h3>
                <p className="text-[10px] text-zinc-500 mb-8 font-mono">{agent.desc}</p>
                
                <div className={`px-4 py-1 border text-[9px] font-bold tracking-[0.2em] uppercase mt-auto transition-all ${
                  agent.status === 'Active' 
                    ? 'bg-[#00FFFF]/10 border-[#00FFFF]/30 text-[#00FFFF] shadow-[0_0_10px_rgba(0,255,255,0.2)]'
                    : 'bg-transparent border-white/10 text-zinc-600'
                }`} style={{ clipPath: 'polygon(0 0, 100% 0, 100% calc(100% - 6px), calc(100% - 6px) 100%, 0 100%)' }}>
                  [{agent.status}]
                </div>
              </div>
            </TechBorder>
          );
        })}
      </div>

      <div className="mt-16 flex justify-center w-full">
        <button className="px-8 py-3 bg-transparent text-[#6137FF] text-[10px] font-bold tracking-[0.2em] uppercase border border-[#6137FF]/30 hover:bg-[#6137FF]/10 hover:text-white transition-all" style={{ clipPath: 'polygon(0 0, 100% 0, 100% calc(100% - 8px), calc(100% - 8px) 100%, 0 100%)' }}>
          Browse All Units
        </button>
      </div>
    </div>
  );
}
