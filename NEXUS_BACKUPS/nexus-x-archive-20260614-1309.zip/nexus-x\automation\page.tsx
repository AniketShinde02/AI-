"use client";

import { Workflow, Plus, Play, Calendar, Zap, FileText, ArrowRight, Activity, Mail } from "lucide-react";

export default function NexusXAutomation() {
  const triggers = [
    { name: "Schedule", desc: "Time-based triggers", icon: Calendar },
    { name: "Event", desc: "System events", icon: Activity },
    { name: "Webhook", desc: "HTTP requests", icon: Zap },
    { name: "Manual", desc: "Manual execution", icon: Play },
  ];

  return (
    <div className="flex-1 flex flex-col max-w-6xl mx-auto w-full h-full pt-4 relative z-10">
      <div className="w-full flex justify-between items-center mb-12">
        <div>
          <h2 className="text-2xl font-quantico font-bold tracking-[0.2em] uppercase text-white mb-2 drop-shadow-md">Automation Core</h2>
          <p className="text-[10px] text-[#00FFFF] uppercase tracking-widest font-mono">Build Powerful Workflows</p>
        </div>
        <button className="flex items-center gap-2 px-6 py-2 bg-transparent border border-[#6137FF] hover:bg-[#6137FF]/10 text-[10px] font-bold text-[#00FFFF] uppercase tracking-[0.2em] transition-all" style={{ clipPath: 'polygon(0 0, 100% 0, 100% calc(100% - 10px), calc(100% - 10px) 100%, 0 100%)' }}>
          <Plus size={14} />
          Initialize Sequence
        </button>
      </div>

      <div className="flex flex-1 gap-8 min-h-0">
        {/* Sidebar: Triggers */}
        <div className="w-64 flex flex-col gap-4 shrink-0">
          <h3 className="text-[10px] font-bold tracking-[0.3em] uppercase text-[#6137FF] flex items-center gap-2">
            <span className="w-2 h-2 bg-[#6137FF] rounded-sm"></span>
            Triggers
          </h3>
          <div className="flex flex-col gap-3">
            {triggers.map(trigger => {
              const Icon = trigger.icon;
              return (
                <div key={trigger.name} className="flex items-center gap-4 p-4 bg-[#06060c] border border-white/5 hover:border-[#6137FF]/50 hover:bg-[#6137FF]/5 cursor-grab transition-all group" style={{ clipPath: 'polygon(0 0, 100% 0, 100% calc(100% - 12px), calc(100% - 12px) 100%, 0 100%)' }}>
                  <div className="w-8 h-8 bg-[#06060c] text-zinc-600 border border-white/10 flex items-center justify-center shrink-0 group-hover:border-[#00FFFF]/50 group-hover:text-[#00FFFF] transition-all">
                    <Icon size={16} />
                  </div>
                  <div>
                    <div className="text-sm font-quantico font-bold text-zinc-300 group-hover:text-white uppercase tracking-wider transition-colors">{trigger.name}</div>
                    <div className="text-[9px] font-mono text-zinc-600">{trigger.desc}</div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Workflow Canvas Mockup */}
        <div className="flex-1 bg-[#06060c]/90 border border-[#6137FF]/20 p-6 relative overflow-hidden flex flex-col shadow-2xl" style={{ clipPath: 'polygon(0 0, 100% 0, 100% calc(100% - 20px), calc(100% - 20px) 100%, 0 100%)' }}>
          <div className="absolute top-0 left-0 w-full h-[2px] bg-gradient-to-r from-transparent via-[#6137FF] to-transparent opacity-50"></div>
          
          {/* Top Canvas Controls */}
          <div className="absolute top-6 left-6 flex items-center gap-2 z-20">
            <div className="px-4 py-2 bg-black/80 border border-[#00FFFF]/30 text-[10px] font-bold text-[#00FFFF] tracking-[0.2em] uppercase backdrop-blur-sm shadow-[0_0_15px_rgba(0,255,255,0.1)]" style={{ clipPath: 'polygon(0 0, 100% 0, 100% calc(100% - 8px), calc(100% - 8px) 100%, 0 100%)' }}>
              Workflow Matrix
            </div>
          </div>
          <div className="absolute top-6 right-6 flex items-center gap-2 bg-black/80 border border-white/10 p-1 z-20" style={{ clipPath: 'polygon(0 0, 100% 0, 100% calc(100% - 8px), calc(100% - 8px) 100%, 0 100%)' }}>
            <button className="p-2 text-zinc-500 hover:text-[#00FFFF] transition-colors"><Activity size={14} /></button>
            <div className="w-[1px] h-4 bg-white/10"></div>
            <button className="p-2 text-zinc-500 hover:text-[#00FFFF] transition-colors"><Search size={14} /></button>
          </div>

          {/* Grid Background */}
          <div className="absolute inset-0 pointer-events-none opacity-[0.03] bg-[linear-gradient(to_right,#80808012_1px,transparent_1px),linear-gradient(to_bottom,#80808012_1px,transparent_1px)] bg-[size:24px_24px] z-0"></div>
          
          {/* Dark Overlay gradient */}
          <div className="absolute inset-0 bg-gradient-to-b from-transparent to-[#06060c] pointer-events-none z-0"></div>

          {/* Nodes Mockup */}
          <div className="flex-1 flex items-center justify-center relative z-10">
            <div className="flex items-center gap-6 relative">
              
              {/* Node 1 */}
              <div className="w-44 bg-black border-l-2 border-[#6137FF] p-4 shadow-[0_4px_15px_rgba(0,0,0,0.5)] flex items-center gap-4">
                <div className="w-8 h-8 bg-[#6137FF]/10 border border-[#6137FF]/30 text-[#6137FF] flex items-center justify-center shrink-0">
                  <Calendar size={14} />
                </div>
                <div>
                  <div className="text-xs font-quantico font-bold text-white uppercase tracking-wider">Schedule</div>
                  <div className="text-[9px] font-mono text-zinc-500">Daily 9:00 AM</div>
                </div>
              </div>

              <div className="h-[2px] w-8 bg-[#6137FF]/50 relative">
                <div className="absolute right-0 top-1/2 -translate-y-1/2 w-2 h-2 rounded-full bg-[#6137FF]"></div>
              </div>

              {/* Node 2 */}
              <div className="w-44 bg-black border-l-2 border-[#00FFFF] p-4 shadow-[0_4px_15px_rgba(0,0,0,0.5)] flex items-center gap-4">
                <div className="w-8 h-8 bg-[#00FFFF]/10 border border-[#00FFFF]/30 text-[#00FFFF] flex items-center justify-center shrink-0">
                  <FileText size={14} />
                </div>
                <div>
                  <div className="text-xs font-quantico font-bold text-white uppercase tracking-wider">Research</div>
                  <div className="text-[9px] font-mono text-zinc-500">AI Trends</div>
                </div>
              </div>

              <div className="h-[2px] w-8 bg-[#00FFFF]/50 relative">
                <div className="absolute right-0 top-1/2 -translate-y-1/2 w-2 h-2 rounded-full bg-[#00FFFF]"></div>
              </div>

              {/* Node 3 */}
              <div className="w-44 bg-black border-l-2 border-[#00FFFF] p-4 shadow-[0_4px_15px_rgba(0,0,0,0.5)] flex items-center gap-4">
                <div className="w-8 h-8 bg-[#00FFFF]/10 border border-[#00FFFF]/30 text-[#00FFFF] flex items-center justify-center shrink-0">
                  <Activity size={14} />
                </div>
                <div>
                  <div className="text-xs font-quantico font-bold text-white uppercase tracking-wider">Summarize</div>
                  <div className="text-[9px] font-mono text-zinc-500">Generate Output</div>
                </div>
              </div>

              <div className="h-[2px] w-8 bg-zinc-700 relative">
                <div className="absolute right-0 top-1/2 -translate-y-1/2 w-2 h-2 rounded-full bg-zinc-500"></div>
              </div>

              {/* Node 4 */}
              <div className="w-44 bg-black border-l-2 border-zinc-700 p-4 shadow-[0_4px_15px_rgba(0,0,0,0.5)] flex items-center gap-4 opacity-50">
                <div className="w-8 h-8 bg-white/5 border border-white/10 text-zinc-500 flex items-center justify-center shrink-0">
                  <Mail size={14} />
                </div>
                <div>
                  <div className="text-xs font-quantico font-bold text-white uppercase tracking-wider">Dispatch</div>
                  <div className="text-[9px] font-mono text-zinc-500">Email Notify</div>
                </div>
              </div>

            </div>
          </div>

          <div className="absolute bottom-8 left-1/2 -translate-x-1/2 z-20">
            <button className="px-8 py-3 bg-[#6137FF]/10 border border-[#6137FF]/40 text-[#00FFFF] text-[10px] font-bold tracking-[0.2em] uppercase hover:bg-[#6137FF]/20 hover:border-[#00FFFF] hover:shadow-[0_0_20px_rgba(0,255,255,0.2)] transition-all" style={{ clipPath: 'polygon(0 0, 100% 0, 100% calc(100% - 10px), calc(100% - 10px) 100%, 0 100%)' }}>
              Execute Sequence
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
