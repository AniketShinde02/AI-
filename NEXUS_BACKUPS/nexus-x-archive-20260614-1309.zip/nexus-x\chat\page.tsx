"use client";

import { useState } from "react";
import { Send, Mic, Paperclip, Bot, User, Activity } from "lucide-react";
import { TechBorder } from "@/components/nexus-x/TechBorder";

export default function NexusXChat() {
  const [inputStr, setInputStr] = useState("");
  
  return (
    <div className="flex-1 flex flex-col items-center justify-center max-w-4xl mx-auto w-full h-full">
      <div className="w-full flex justify-between items-center mb-6">
        <h2 className="text-xl font-bold tracking-widest uppercase text-white">Neural Chat</h2>
        <div className="flex items-center gap-3">
          <button className="flex items-center gap-2 px-3 py-1.5 bg-white/5 hover:bg-white/10 rounded-lg text-xs font-semibold text-zinc-400 hover:text-white transition-colors border border-white/5">
            <Activity size={14} className="text-violet-500" />
            Show Trace
          </button>
        </div>
      </div>

      <div className="flex-1 w-full bg-black/40 border border-[#6137FF]/10 p-6 overflow-y-auto mb-6 flex flex-col gap-6" style={{ clipPath: 'polygon(0 0, 100% 0, 100% calc(100% - 15px), calc(100% - 15px) 100%, 0 100%)' }}>
        {/* Assistant Message */}
        <div className="flex gap-4 max-w-[85%]">
          <div className="w-8 h-8 rounded bg-violet-600/20 border border-violet-500/30 flex items-center justify-center shrink-0 shadow-[0_0_10px_rgba(97,55,255,0.3)]">
            <Bot size={16} className="text-violet-400" />
          </div>
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-[#00FFFF] uppercase tracking-widest drop-shadow-md">Nexus X</span>
              <span className="text-[10px] text-zinc-600 font-mono">10:45 AM</span>
            </div>
            <div className="text-sm text-zinc-300 leading-relaxed bg-[#06060c] p-4 border-l-2 border-[#6137FF] shadow-[0_4px_15px_rgba(0,0,0,0.5)]">
              I'm analyzing the latest trends for 2026. Here is the overview you requested:
              <ul className="mt-3 space-y-2 pl-4 list-disc text-zinc-400 marker:text-[#00FFFF]">
                <li>Multimodal AI is dominating.</li>
                <li>Real-time reasoning models.</li>
                <li>Agents are becoming autonomous.</li>
                <li>Edge AI is scaling fast.</li>
              </ul>
              <br />
              Would you like a detailed report?
            </div>
          </div>
        </div>

        {/* User Message */}
        <div className="flex gap-4 max-w-[85%] self-end flex-row-reverse">
          <div className="w-8 h-8 rounded bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center shrink-0">
            <User size={16} className="text-emerald-400" />
          </div>
          <div className="space-y-2 flex flex-col items-end">
            <div className="flex items-center gap-2">
              <span className="text-[10px] text-zinc-600 font-mono">10:46 AM</span>
              <span className="text-xs font-bold text-emerald-400 uppercase tracking-widest">Aniket</span>
            </div>
            <div className="text-sm text-zinc-200 leading-relaxed bg-violet-900/20 p-4 border-r-2 border-emerald-500 shadow-[0_4px_15px_rgba(0,0,0,0.5)] text-right">
              Yes, save it to my projects and give me a quick summary.
            </div>
          </div>
        </div>
      </div>

      <div className="w-full relative">
        <TechBorder glowColor="#00FFFF">
          <div className="relative glass bg-[#06060c]/90 p-2 flex items-center gap-2 shadow-2xl z-10">
            <button className="w-10 h-10 flex items-center justify-center text-zinc-500 hover:text-[#00FFFF] transition-colors">
              <Paperclip size={18} />
            </button>
            
            <input 
              type="text" 
              placeholder="Awaiting command..."
              value={inputStr}
              onChange={e => setInputStr(e.target.value)}
              className="flex-1 bg-transparent border-none text-white placeholder:text-zinc-600 focus:outline-none text-sm tracking-wide font-mono"
            />

            <button className="w-10 h-10 flex items-center justify-center text-zinc-500 hover:text-[#00FFFF] transition-colors">
              <Mic size={18} />
            </button>

            <button 
              disabled={!inputStr.trim()}
              className="w-10 h-10 flex items-center justify-center text-[#6137FF] disabled:text-zinc-700 hover:text-[#00FFFF] transition-colors"
            >
              <Send size={18} className="translate-x-0.5" />
            </button>
          </div>
        </TechBorder>
      </div>
    </div>
  );
}
