"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  Home,
  MessageSquare,
  BrainCircuit,
  Bot,
  Workflow,
  Settings,
  Activity,
  Zap
} from "lucide-react";

export default function NexusXLayout({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();

  const navItems = [
    { name: "Dashboard", href: "/nexus-x", icon: Home },
    { name: "Chat", href: "/nexus-x/chat", icon: MessageSquare },
    { name: "Trace", href: "/nexus-x/trace", icon: Activity },
    { name: "Memory", href: "/nexus-x/memory", icon: BrainCircuit },
    { name: "Agents", href: "/nexus-x/agents", icon: Bot },
    { name: "Automation", href: "/nexus-x/automation", icon: Workflow },
    { name: "Settings", href: "/nexus-x/settings", icon: Settings },
  ];

  return (
    <div className="min-h-screen bg-[#06060c] text-white selection:bg-violet-500/30 overflow-hidden flex flex-col font-sans relative">
      {/* Shadow Monarch Background */}
      <div className="absolute inset-0 z-0 pointer-events-none">
        {/* Subtle Tech Grid */}
        <div className="absolute inset-0 opacity-[0.03] bg-[linear-gradient(to_right,#80808012_1px,transparent_1px),linear-gradient(to_bottom,#80808012_1px,transparent_1px)] bg-[size:24px_24px]"></div>
        
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[80vw] h-[40vh] bg-violet-900/10 blur-[120px] rounded-full"></div>
        <div className="absolute bottom-0 left-0 w-[50vw] h-[50vh] bg-indigo-900/10 blur-[120px] rounded-full"></div>
      </div>

      {/* Top Navigation Header */}
      <header className="h-16 shrink-0 z-20 px-8 flex items-center justify-between border-b border-white/[0.02] bg-gradient-to-b from-[#06060c] to-transparent">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded bg-violet-600/20 border border-violet-500/30 flex items-center justify-center">
            <Zap className="text-violet-400 w-4 h-4" />
          </div>
          <div className="flex flex-col">
            <span className="text-sm font-quantico font-bold tracking-widest uppercase text-white">NEXUS X</span>
            <span className="text-[9px] font-mono tracking-widest text-violet-400 uppercase">Shadow Protocol</span>
          </div>
        </div>

        <nav className="flex items-center gap-6">
          {navItems.map((item) => {
            const isActive = pathname === item.href;
            const Icon = item.icon;
            return (
              <Link
                key={item.name}
                href={item.href}
                className={`group relative flex items-center gap-2 pb-2 pt-2 transition-all text-[11px] font-quantico font-bold tracking-[0.15em] uppercase ${
                  isActive 
                    ? 'text-white' 
                    : 'text-zinc-600 hover:text-zinc-300'
                }`}
              >
                <Icon className={`w-3.5 h-3.5 transition-colors ${isActive ? 'text-[#00FFFF]' : 'text-zinc-600 group-hover:text-zinc-400'}`} />
                {item.name}
                {isActive && (
                  <div className="absolute bottom-0 left-0 right-0 h-[2px] bg-gradient-to-r from-transparent via-[#00FFFF] to-transparent shadow-[0_0_8px_rgba(0,255,255,0.8)]"></div>
                )}
              </Link>
            );
          })}
        </nav>

        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2 px-3 py-1 bg-emerald-500/10 border border-emerald-500/20 rounded-full">
            <div className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></div>
            <span className="text-[10px] font-bold tracking-widest uppercase text-emerald-400">Online</span>
          </div>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 z-10 relative overflow-hidden flex flex-col p-6">
        {children}
      </main>
    </div>
  );
}
