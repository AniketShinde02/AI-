"use client";

import { User, Folder, MessageSquare, Bookmark, Database, Search, Plus } from "lucide-react";

export default function NexusXMemory() {
  const categories = [
    { name: "User Preferences", icon: User, count: 24, active: true },
    { name: "Projects", icon: Folder, count: 12, active: false },
    { name: "Conversations", icon: MessageSquare, count: 156, active: false },
    { name: "Saved Facts", icon: Bookmark, count: 89, active: false },
    { name: "Knowledge Base", icon: Database, count: 342, active: false },
  ];

  const recentMemories = [
    { title: "AI Trends Analysis", time: "Today, 1:45 PM", type: "Project" },
    { title: "Nexus X System Overview", time: "Today, 12:20 PM", type: "Note" },
    { title: "User Preferences Updated", time: "Yesterday, 8:20 PM", type: "System" },
    { title: "Shadow Monarch Mode Activated", time: "Yesterday, 8:10 PM", type: "System" },
    { title: "Voice Commands Guide", time: "2 days ago, 4:30 PM", type: "Guide" },
  ];

  return (
    <div className="flex-1 flex flex-col max-w-6xl mx-auto w-full h-full pt-4 relative z-10">
      <div className="w-full flex justify-between items-center mb-8">
        <div>
          <h2 className="text-2xl font-quantico font-bold tracking-[0.2em] uppercase text-white mb-2 drop-shadow-md">Memory Vault</h2>
          <p className="text-[10px] text-[#00FFFF] uppercase tracking-widest font-mono">Your Knowledge. Your Rules.</p>
        </div>
        <div className="flex items-center gap-4">
          <div className="relative group">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-500 group-focus-within:text-[#00FFFF] transition-colors" />
            <input 
              type="text" 
              placeholder="QUERY MEMORY..."
              className="pl-9 pr-4 py-2 bg-[#06060c] border border-white/10 text-[10px] font-quantico font-bold tracking-widest text-white placeholder:text-zinc-600 focus:outline-none focus:border-[#00FFFF] w-64 transition-all"
              style={{ clipPath: 'polygon(0 0, 100% 0, 100% calc(100% - 10px), calc(100% - 10px) 100%, 0 100%)' }}
            />
          </div>
          <button className="flex items-center gap-2 px-6 py-2 bg-transparent border border-[#6137FF] hover:bg-[#6137FF]/10 text-[10px] font-bold text-[#00FFFF] uppercase tracking-[0.2em] transition-all" style={{ clipPath: 'polygon(0 0, 100% 0, 100% calc(100% - 10px), calc(100% - 10px) 100%, 0 100%)' }}>
            <Plus size={14} />
            Initialize
          </button>
        </div>
      </div>

      <div className="flex flex-1 gap-8 min-h-0">
        {/* Categories Sidebar */}
        <div className="w-64 flex flex-col gap-3 shrink-0">
          {categories.map(cat => {
            const Icon = cat.icon;
            return (
              <button key={cat.name} className={`group flex items-center gap-4 p-4 border transition-all text-left ${
                cat.active 
                  ? 'bg-[#00FFFF]/5 border-[#00FFFF]/30 shadow-[0_0_15px_rgba(0,255,255,0.1)]' 
                  : 'bg-[#06060c]/80 border-white/5 hover:border-white/20'
              }`} style={{ clipPath: 'polygon(0 0, 100% 0, 100% calc(100% - 12px), calc(100% - 12px) 100%, 0 100%)' }}>
                <div className={`w-8 h-8 flex items-center justify-center shrink-0 transition-colors ${
                  cat.active ? 'text-[#00FFFF]' : 'text-zinc-600 group-hover:text-zinc-400'
                }`}>
                  <Icon size={18} />
                </div>
                <div>
                  <div className={`text-xs font-quantico font-bold tracking-widest uppercase transition-colors ${
                    cat.active ? 'text-white' : 'text-zinc-500 group-hover:text-zinc-300'
                  }`}>{cat.name}</div>
                  <div className={`text-[9px] font-mono tracking-wider mt-1 ${cat.active ? 'text-[#6137FF]' : 'text-zinc-600'}`}>[{cat.count} ENGRAMS]</div>
                </div>
              </button>
            );
          })}
        </div>

        {/* Memory List */}
        <div className="flex-1 bg-[#06060c]/90 border border-[#6137FF]/20 p-8 overflow-y-auto shadow-2xl relative" style={{ clipPath: 'polygon(0 0, 100% 0, 100% calc(100% - 20px), calc(100% - 20px) 100%, 0 100%)' }}>
          <div className="absolute top-0 left-0 w-full h-[2px] bg-gradient-to-r from-transparent via-[#6137FF] to-transparent opacity-50"></div>
          
          <h3 className="text-[10px] font-bold tracking-[0.3em] uppercase text-[#00FFFF] mb-6 flex items-center gap-2">
            <span className="w-2 h-2 bg-[#00FFFF] rounded-sm"></span>
            Recent Engrams
          </h3>
          
          <div className="space-y-3">
            {recentMemories.map((mem, i) => (
              <div key={i} className="flex items-center justify-between p-5 border border-white/5 bg-black hover:border-[#6137FF]/50 hover:bg-[#6137FF]/5 cursor-pointer transition-all group" style={{ clipPath: 'polygon(0 0, 100% 0, 100% calc(100% - 10px), calc(100% - 10px) 100%, 0 100%)' }}>
                <div className="flex items-center gap-6">
                  <div className="w-8 h-8 bg-[#06060c] border border-white/10 flex items-center justify-center group-hover:border-[#00FFFF]/50 group-hover:shadow-[0_0_10px_rgba(0,255,255,0.2)] transition-all">
                    <Bookmark size={14} className="text-zinc-600 group-hover:text-[#00FFFF] transition-colors" />
                  </div>
                  <div>
                    <div className="text-sm font-quantico font-bold tracking-wide text-zinc-300 group-hover:text-white transition-colors">{mem.title}</div>
                    <div className="text-[10px] font-mono text-zinc-600 mt-1 uppercase">{mem.time}</div>
                  </div>
                </div>
                <div className="px-3 py-1 border border-white/10 text-[9px] font-bold font-mono text-zinc-600 uppercase tracking-widest group-hover:border-[#6137FF] group-hover:text-[#6137FF] transition-all bg-[#06060c]">
                  {mem.type}
                </div>
              </div>
            ))}
          </div>

          <div className="mt-12 flex justify-center">
            <button className="px-8 py-3 bg-transparent text-[#6137FF] text-[10px] font-bold tracking-[0.2em] uppercase border border-[#6137FF]/30 hover:bg-[#6137FF]/10 hover:text-white transition-all" style={{ clipPath: 'polygon(0 0, 100% 0, 100% calc(100% - 8px), calc(100% - 8px) 100%, 0 100%)' }}>
              Access Full Archive
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
