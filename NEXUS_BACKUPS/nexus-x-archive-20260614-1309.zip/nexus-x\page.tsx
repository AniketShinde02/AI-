"use client";

import { useState, useEffect } from "react";
import { Mic, Send, Command, Activity, Zap, Search, Settings } from "lucide-react";
import { ShadowDiamond } from "@/components/nexus-x/ShadowDiamond";
import { TechBorder } from "@/components/nexus-x/TechBorder";
import { MonarchAvatar } from "@/components/nexus-x/MonarchAvatar";

export default function NexusXHome() {
  const [isListening, setIsListening] = useState(false);
  const [inputStr, setInputStr] = useState("");

  return (
    <div className="flex-1 flex flex-col items-center justify-center relative">
      
      {/* Central WebGL Shadow Entity - Massive Background Mode */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-[60%] w-[100vw] h-[80vh] flex items-center justify-center pointer-events-auto z-0 opacity-80 mix-blend-screen">
        <MonarchAvatar imageUrl="/assets/monarch/monarch/shadow_monarch_idle.png" isListening={isListening} />
      </div>

      {/* Greeting & Status */}
      <div className="text-center mb-12 space-y-3 z-10 mt-auto pt-[40vh]">
        <h1 className="text-4xl font-quantico font-black tracking-tighter text-transparent bg-clip-text bg-gradient-to-b from-white to-zinc-500 drop-shadow-2xl">
          I AM ALL EARS, ANIKET.
        </h1>
        <div className="flex items-center justify-center gap-2">
          <div className="w-12 h-[2px] bg-white/10 overflow-hidden">
            <div className={`h-full bg-[#00FFFF] transition-all duration-500 ${isListening ? 'w-full animate-pulse shadow-[0_0_10px_#00FFFF]' : 'w-1/3'}`}></div>
          </div>
          <span className="text-[10px] font-bold uppercase tracking-[0.3em] text-[#00FFFF] drop-shadow-md">
            {isListening ? 'Synchronizing' : 'Standby'}
          </span>
          <div className="w-12 h-[2px] bg-white/10 overflow-hidden">
            <div className={`h-full bg-[#00FFFF] transition-all duration-500 ${isListening ? 'w-full animate-pulse shadow-[0_0_10px_#00FFFF]' : 'w-1/3'}`}></div>
          </div>
        </div>
      </div>

      {/* Voice / Text Input Center */}
      <div className="w-full max-w-2xl relative">
        <div className="absolute -inset-1 bg-gradient-to-r from-violet-500/20 via-indigo-500/20 to-violet-500/20 rounded-2xl blur-lg opacity-50"></div>
        
        <TechBorder glowColor="#00FFFF">
          <div className="relative glass bg-zinc-950/80 p-2 flex items-center gap-4 shadow-2xl z-10">
            <button className="w-10 h-10 flex items-center justify-center text-zinc-500 hover:text-[#00FFFF] transition-colors">
              <Command size={18} />
            </button>
            
            <input 
              type="text" 
              placeholder="Ask Nexus anything..."
              value={inputStr}
              onChange={e => setInputStr(e.target.value)}
              className="flex-1 bg-transparent border-none text-white placeholder:text-zinc-600 focus:outline-none text-sm tracking-wide font-medium"
            />

            {/* Using the Solo Leveling Shadow Diamond for the core action */}
            <ShadowDiamond 
              active={isListening} 
              size={52} 
              onClick={() => setIsListening(!isListening)}
              className="mx-2"
            >
              <Mic size={20} />
            </ShadowDiamond>

            <button className="w-10 h-10 flex items-center justify-center text-zinc-500 hover:text-white transition-colors">
              <Settings size={18} />
            </button>

            <button 
              disabled={!inputStr.trim()}
              className="w-10 h-10 flex items-center justify-center text-[#6137FF] disabled:text-zinc-700 hover:text-[#00FFFF] transition-colors"
            >
              <Send size={18} className="translate-x-0.5" />
            </button>
          </div>
        </TechBorder>
      </div>

      {/* Bottom Context Mini-Panel */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex items-center gap-6 opacity-60 hover:opacity-100 transition-opacity">
        <div className="flex items-center gap-2 text-[10px] font-bold uppercase tracking-widest text-zinc-400">
          <Activity size={12} className="text-violet-400" />
          <span>System Nominal</span>
        </div>
        <div className="w-1 h-1 rounded-full bg-zinc-700"></div>
        <div className="flex items-center gap-2 text-[10px] font-bold uppercase tracking-widest text-zinc-400">
          <Zap size={12} className="text-violet-400" />
          <span>Shadow Level: Max</span>
        </div>
      </div>
    </div>
  );
}
