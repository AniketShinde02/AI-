"use client";

import { Settings2, Cpu, Mic, Database, Shield, Key, Layout } from "lucide-react";

export default function NexusXSettings() {
  const sections = [
    { id: "general", name: "General", desc: "Basic settings", icon: Settings2, active: true },
    { id: "models", name: "AI Models", desc: "Model preferences", icon: Cpu, active: false },
    { id: "voice", name: "Voice & Audio", desc: "Voice settings", icon: Mic, active: false },
    { id: "memory", name: "Memory", desc: "Memory settings", icon: Database, active: false },
    { id: "security", name: "Security", desc: "Privacy & security", icon: Shield, active: false },
    { id: "api", name: "API Keys", desc: "Manage keys", icon: Key, active: false },
    { id: "appearance", name: "Appearance", desc: "Theme & Display", icon: Layout, active: false },
  ];

  return (
    <div className="flex-1 flex flex-col max-w-6xl mx-auto w-full h-full pt-4 relative z-10">
      <div className="w-full flex justify-between items-center mb-12">
        <div>
          <h2 className="text-2xl font-quantico font-bold tracking-[0.2em] uppercase text-white mb-2 drop-shadow-md">Command Center</h2>
          <p className="text-[10px] text-[#00FFFF] uppercase tracking-widest font-mono">System Configuration Matrix</p>
        </div>
      </div>

      <div className="flex flex-1 gap-8 min-h-0">
        {/* Settings Navigation */}
        <div className="w-64 flex flex-col gap-3 shrink-0">
          {sections.map(sec => {
            const Icon = sec.icon;
            return (
              <button key={sec.id} className={`group flex items-center gap-4 p-4 border transition-all text-left ${
                sec.active 
                  ? 'bg-[#00FFFF]/5 border-[#00FFFF]/30 shadow-[0_0_15px_rgba(0,255,255,0.1)]' 
                  : 'bg-[#06060c]/80 border-white/5 hover:border-white/20'
              }`} style={{ clipPath: 'polygon(0 0, 100% 0, 100% calc(100% - 12px), calc(100% - 12px) 100%, 0 100%)' }}>
                <div className={`w-8 h-8 flex items-center justify-center shrink-0 transition-colors ${
                  sec.active ? 'text-[#00FFFF]' : 'text-zinc-600 group-hover:text-zinc-400'
                }`}>
                  <Icon size={18} />
                </div>
                <div>
                  <div className={`text-xs font-quantico font-bold tracking-widest uppercase transition-colors ${
                    sec.active ? 'text-white' : 'text-zinc-500 group-hover:text-zinc-300'
                  }`}>{sec.name}</div>
                  <div className={`text-[9px] font-mono tracking-wider mt-1 ${sec.active ? 'text-[#6137FF]' : 'text-zinc-600'}`}>{sec.desc}</div>
                </div>
              </button>
            );
          })}
        </div>

        {/* Settings Content Area */}
        <div className="flex-1 bg-[#06060c]/90 border border-[#6137FF]/20 p-8 overflow-y-auto shadow-2xl relative" style={{ clipPath: 'polygon(0 0, 100% 0, 100% calc(100% - 20px), calc(100% - 20px) 100%, 0 100%)' }}>
          <div className="absolute top-0 left-0 w-full h-[2px] bg-gradient-to-r from-transparent via-[#6137FF] to-transparent opacity-50"></div>
          
          <h3 className="text-[10px] font-bold tracking-[0.3em] uppercase text-[#00FFFF] mb-8 pb-4 border-b border-white/5 flex items-center gap-2">
            <span className="w-2 h-2 bg-[#00FFFF] rounded-sm"></span>
            General Parameters
          </h3>
          
          <div className="space-y-8">
            
            {/* Setting Item */}
            <div className="flex items-center justify-between">
              <div>
                <div className="text-sm font-quantico font-bold text-zinc-300 uppercase tracking-wide">System Language</div>
                <div className="text-[10px] font-mono text-zinc-600 mt-1 uppercase">Primary language for interface</div>
              </div>
              <div className="w-48 px-4 py-2 bg-black border border-[#6137FF]/30 text-[10px] font-bold text-white uppercase tracking-widest shadow-[inset_0_0_10px_rgba(97,55,255,0.1)]" style={{ clipPath: 'polygon(0 0, 100% 0, 100% calc(100% - 8px), calc(100% - 8px) 100%, 0 100%)' }}>
                English [EN-US]
              </div>
            </div>

            {/* Setting Item */}
            <div className="flex items-center justify-between">
              <div>
                <div className="text-sm font-quantico font-bold text-zinc-300 uppercase tracking-wide">Timezone</div>
                <div className="text-[10px] font-mono text-zinc-600 mt-1 uppercase">Local coordinate tracking</div>
              </div>
              <div className="w-48 px-4 py-2 bg-black border border-[#6137FF]/30 text-[10px] font-bold text-white uppercase tracking-widest shadow-[inset_0_0_10px_rgba(97,55,255,0.1)]" style={{ clipPath: 'polygon(0 0, 100% 0, 100% calc(100% - 8px), calc(100% - 8px) 100%, 0 100%)' }}>
                (UTC+05:30) ASIA/KOL
              </div>
            </div>

            {/* Setting Item */}
            <div className="flex items-center justify-between">
              <div>
                <div className="text-sm font-quantico font-bold text-zinc-300 uppercase tracking-wide">Response Style</div>
                <div className="text-[10px] font-mono text-zinc-600 mt-1 uppercase">Output generation protocol</div>
              </div>
              <div className="w-48 px-4 py-2 bg-[#00FFFF]/5 border border-[#00FFFF]/30 text-[10px] font-bold text-[#00FFFF] uppercase tracking-widest shadow-[0_0_10px_rgba(0,255,255,0.1)]" style={{ clipPath: 'polygon(0 0, 100% 0, 100% calc(100% - 8px), calc(100% - 8px) 100%, 0 100%)' }}>
                Shadow Monarch
              </div>
            </div>

            <div className="border-t border-white/5 pt-8"></div>

            {/* Toggle Item */}
            <div className="flex items-center justify-between">
              <div>
                <div className="text-sm font-quantico font-bold text-zinc-300 uppercase tracking-wide">Auto-save Engrams</div>
                <div className="text-[10px] font-mono text-zinc-600 mt-1 uppercase">Store conversation history to Memory Vault</div>
              </div>
              <div className="flex items-center gap-2 px-4 py-2 bg-[#00FFFF]/10 border border-[#00FFFF]/30" style={{ clipPath: 'polygon(0 0, 100% 0, 100% calc(100% - 6px), calc(100% - 6px) 100%, 0 100%)' }}>
                <div className="w-2 h-2 bg-[#00FFFF] shadow-[0_0_8px_#00FFFF] animate-pulse"></div>
                <span className="text-[9px] font-bold tracking-[0.2em] uppercase text-[#00FFFF]">Active</span>
              </div>
            </div>

            {/* Toggle Item */}
            <div className="flex items-center justify-between">
              <div>
                <div className="text-sm font-quantico font-bold text-zinc-300 uppercase tracking-wide">System Notifications</div>
                <div className="text-[10px] font-mono text-zinc-600 mt-1 uppercase">Receive background execution alerts</div>
              </div>
              <div className="flex items-center gap-2 px-4 py-2 bg-[#00FFFF]/10 border border-[#00FFFF]/30" style={{ clipPath: 'polygon(0 0, 100% 0, 100% calc(100% - 6px), calc(100% - 6px) 100%, 0 100%)' }}>
                <div className="w-2 h-2 bg-[#00FFFF] shadow-[0_0_8px_#00FFFF] animate-pulse"></div>
                <span className="text-[9px] font-bold tracking-[0.2em] uppercase text-[#00FFFF]">Active</span>
              </div>
            </div>

            <div className="border-t border-white/5 pt-8"></div>
            
            {/* System Status Section */}
            <h3 className="text-[10px] font-bold tracking-[0.3em] uppercase text-[#6137FF] mb-6 flex items-center gap-2">
              <span className="w-2 h-2 bg-[#6137FF] rounded-sm"></span>
              Core Diagnostics
            </h3>
            
            <div className="bg-black border border-white/5 p-6" style={{ clipPath: 'polygon(0 0, 100% 0, 100% calc(100% - 15px), calc(100% - 15px) 100%, 0 100%)' }}>
              <div className="space-y-4">
                <div className="flex justify-between items-center border-b border-white/5 pb-2">
                  <span className="text-[10px] font-mono uppercase text-zinc-500 tracking-wider">Protocol Version</span>
                  <span className="text-[10px] font-mono uppercase text-[#00FFFF]">v3.0.0-shadow</span>
                </div>
                <div className="flex justify-between items-center border-b border-white/5 pb-2">
                  <span className="text-[10px] font-mono uppercase text-zinc-500 tracking-wider">Last Sync</span>
                  <span className="text-[10px] font-mono uppercase text-white">Current Session</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-[10px] font-mono uppercase text-zinc-500 tracking-wider">Core Uptime</span>
                  <span className="text-[10px] font-mono uppercase text-[#00FFFF] animate-pulse">Stable</span>
                </div>
              </div>
            </div>

          </div>
        </div>
      </div>
    </div>
  );
}
