"use client";

import { Activity, Search, Server, Zap, Mic, Volume2 } from "lucide-react";

export default function NexusXTrace() {
  const traces = [
    { id: 1, time: "13:45:21", icon: Mic, label: "Understanding query", color: "text-blue-400" },
    { id: 2, time: "13:45:22", icon: Search, label: "Searching knowledge base", color: "text-indigo-400" },
    { id: 3, time: "13:45:23", icon: Server, label: "Gathering real-time data", color: "text-violet-400" },
    { id: 4, time: "13:45:24", icon: Activity, label: "Analyzing results", color: "text-fuchsia-400" },
    { id: 5, time: "13:45:25", icon: Zap, label: "Generating response", color: "text-pink-400" },
    { id: 6, time: "13:45:26", icon: Volume2, label: "Response ready", color: "text-emerald-400" },
  ];

  return (
    <div className="flex-1 flex flex-col items-center max-w-4xl mx-auto w-full h-full pt-8 relative z-10">
      <div className="w-full flex justify-between items-center mb-12">
        <div>
          <h2 className="text-2xl font-quantico font-bold tracking-[0.2em] uppercase text-white mb-2 drop-shadow-md">Live Trace</h2>
          <p className="text-[10px] text-[#00FFFF] uppercase tracking-widest font-mono">System Execution Timeline</p>
        </div>
      </div>

      <div className="w-full bg-[#06060c]/90 border border-[#6137FF]/20 p-10 shadow-2xl relative" style={{ clipPath: 'polygon(0 0, 100% 0, 100% calc(100% - 20px), calc(100% - 20px) 100%, 0 100%)' }}>
        <div className="absolute top-0 left-0 w-1 h-full bg-gradient-to-b from-[#00FFFF] via-[#6137FF] to-transparent"></div>

        <div className="relative pl-6">
          {/* Vertical Timeline Line */}
          <div className="absolute left-[28px] top-6 bottom-6 w-[2px] bg-gradient-to-b from-[#00FFFF] via-[#6137FF] to-transparent opacity-30 shadow-[0_0_10px_#00FFFF]"></div>

          <div className="space-y-10 relative">
            {traces.map((trace, index) => {
              const Icon = trace.icon;
              const isActive = index === traces.length - 1; // Highlight the last trace
              
              return (
                <div key={trace.id} className="flex items-center gap-8 group">
                  <div className={`w-8 h-8 rounded border flex items-center justify-center shrink-0 z-10 transition-all ${
                    isActive 
                      ? 'border-[#00FFFF] bg-[#00FFFF]/10 text-[#00FFFF] shadow-[0_0_15px_rgba(0,255,255,0.4)] animate-pulse' 
                      : 'border-[#6137FF]/40 bg-[#06060c] text-zinc-500 group-hover:text-[#6137FF] group-hover:border-[#6137FF]'
                  }`}>
                    <Icon size={14} />
                  </div>
                  
                  <div className={`flex-1 flex items-center justify-between p-4 border transition-colors ${
                    isActive
                      ? 'border-[#00FFFF]/30 bg-[#00FFFF]/5 shadow-[0_0_20px_rgba(0,255,255,0.1)]'
                      : 'border-transparent group-hover:border-white/5 group-hover:bg-white/[0.02]'
                  }`} style={{ clipPath: 'polygon(0 0, 100% 0, 100% calc(100% - 10px), calc(100% - 10px) 100%, 0 100%)' }}>
                    <span className={`text-sm font-quantico font-bold tracking-widest uppercase ${isActive ? 'text-white' : 'text-zinc-400'}`}>
                      {trace.label}
                    </span>
                    <span className="text-[10px] font-mono text-zinc-600 tracking-wider">{trace.time}</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        <div className="mt-16 flex justify-end">
          <button className="px-6 py-2 bg-transparent text-[#00FFFF] text-[10px] font-bold tracking-[0.2em] uppercase border border-[#00FFFF]/30 hover:bg-[#00FFFF]/10 transition-all" style={{ clipPath: 'polygon(0 0, 100% 0, 100% calc(100% - 8px), calc(100% - 8px) 100%, 0 100%)' }}>
            [ View System Log ]
          </button>
        </div>
      </div>
    </div>
  );
}
