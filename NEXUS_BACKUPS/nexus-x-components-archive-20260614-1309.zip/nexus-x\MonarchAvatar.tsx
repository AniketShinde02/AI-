"use client";

import React, { useRef, useMemo } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { useTexture, Sparkles } from '@react-three/drei';
import * as THREE from 'three';

interface AvatarSceneProps {
  imageUrl: string;
  isListening: boolean;
}

function AvatarScene({ imageUrl, isListening }: AvatarSceneProps) {
  const meshRef = useRef<THREE.Mesh>(null);
  
  // Load the 2D image as a texture
  const texture = useTexture(imageUrl);

  // Animate the image based on mouse position to create a parallax 2.5D effect
  useFrame((state) => {
    if (!meshRef.current) return;
    
    // Calculate target rotation based on mouse pointer
    const targetX = (state.pointer.x * Math.PI) / 10;
    const targetY = (state.pointer.y * Math.PI) / 10;

    // Smoothly interpolate current rotation to target rotation
    meshRef.current.rotation.y = THREE.MathUtils.lerp(meshRef.current.rotation.y, targetX, 0.1);
    meshRef.current.rotation.x = THREE.MathUtils.lerp(meshRef.current.rotation.x, -targetY, 0.1);
  });

  // Calculate the aspect ratio to maintain the image's proportions
  const aspect = texture.image ? texture.image.width / texture.image.height : 1;

  return (
    <group>
      {/* The main avatar image */}
      <mesh ref={meshRef} position={[0, 0, 0]}>
        <planeGeometry args={[10 * aspect, 10]} />
        <meshBasicMaterial 
          map={texture} 
          transparent={true} 
          side={THREE.DoubleSide} 
        />
      </mesh>

      {/* Shadow Monarch Aura Particles */}
      <Sparkles 
        count={isListening ? 400 : 150} 
        scale={[12, 12, 5]} 
        size={isListening ? 4 : 2} 
        speed={isListening ? 0.8 : 0.2} 
        opacity={0.6} 
        color="#6137FF" 
        position={[0, -2, -1]}
      />
      
      {/* Cyan secondary tech particles */}
      <Sparkles 
        count={50} 
        scale={[10, 10, 2]} 
        size={1} 
        speed={0.4} 
        opacity={0.3} 
        color="#00FFFF" 
        position={[0, 0, 0]}
      />
    </group>
  );
}

interface MonarchAvatarProps {
  imageUrl: string;
  isListening: boolean;
  className?: string;
}

export function MonarchAvatar({ imageUrl, isListening, className }: MonarchAvatarProps) {
  return (
    <div className={`relative w-full h-full overflow-hidden ${className || ''}`}>
      {/* WebGL Canvas */}
      <Canvas camera={{ position: [0, 0, 8], fov: 50 }}>
        <AvatarScene imageUrl={imageUrl} isListening={isListening} />
      </Canvas>
      
      {/* Vignette Overlay to blend the hard edges of the image */}
      <div className="absolute inset-0 pointer-events-none bg-[radial-gradient(ellipse_at_center,transparent_20%,#06060c_80%)]"></div>
    </div>
  );
}
