import React from 'react';
import { cn } from '@/lib/utils';

interface ShadowButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  children: React.ReactNode;
  variant?: 'primary' | 'secondary' | 'ghost';
  cutSize?: number;
}

export function ShadowButton({ 
  children, 
  className, 
  variant = 'primary', 
  cutSize = 12,
  ...props 
}: ShadowButtonProps) {
  
  // Base classes that apply to all variants
  const baseClasses = "relative font-quantico font-bold tracking-widest uppercase px-8 py-3 transition-all duration-300 group overflow-hidden outline-none";
  
  // Specific variant classes
  const variants = {
    primary: "bg-[#6137FF] text-white hover:bg-[#7a54ff]",
    secondary: "bg-black text-[#6137FF] border-2 border-[#6137FF] hover:bg-[#6137FF]/10",
    ghost: "bg-transparent text-zinc-400 hover:text-white"
  };

  // Construct the clip-path style for the diagonal right corner cut
  const clipStyle = {
    clipPath: variant !== 'ghost' 
      ? `polygon(0 0, 100% 0, 100% calc(100% - ${cutSize}px), calc(100% - ${cutSize}px) 100%, 0 100%)`
      : 'none'
  };

  return (
    <div className={cn("relative inline-block", className)}>
      {/* Outer Glow Effect (Only visible on hover for primary) */}
      {variant === 'primary' && (
        <div 
          className="absolute inset-0 bg-[#6137FF] blur-md opacity-0 group-hover:opacity-60 transition-opacity duration-300"
          style={{ ...clipStyle, transform: 'scale(1.05)' }}
        ></div>
      )}

      {/* The Actual Button */}
      <button 
        className={cn(baseClasses, variants[variant])}
        style={clipStyle}
        {...props}
      >
        <span className="relative z-10">{children}</span>
        
        {/* Hover Highlight line inside the button */}
        {variant !== 'ghost' && (
          <div className="absolute top-0 left-0 w-full h-[1px] bg-white/30 transform -translate-x-full group-hover:translate-x-full transition-transform duration-700"></div>
        )}
      </button>
    </div>
  );
}
