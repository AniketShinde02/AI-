import React from 'react';
import { cn } from '@/lib/utils';

interface ShadowDiamondProps {
  children: React.ReactNode;
  active?: boolean;
  size?: number;
  className?: string;
  onClick?: () => void;
}

export function ShadowDiamond({ 
  children, 
  active = false, 
  size = 48, 
  className,
  onClick 
}: ShadowDiamondProps) {
  
  return (
    <div 
      className={cn(
        "relative flex items-center justify-center cursor-pointer group transition-all duration-300",
        className
      )}
      style={{ width: size, height: size }}
      onClick={onClick}
    >
      {/* Outer Diamond Shape */}
      <div 
        className={cn(
          "absolute inset-0 bg-black border transform rotate-45 transition-all duration-300",
          active 
            ? "border-[#6137FF] shadow-[0_0_15px_rgba(97,55,255,0.6)] scale-110" 
            : "border-white/20 group-hover:border-[#6137FF]/50 group-hover:scale-105"
        )}
      ></div>

      {/* Optional Inner glow for active state */}
      {active && (
        <div className="absolute inset-1 bg-[#6137FF]/20 transform rotate-45 blur-sm"></div>
      )}

      {/* Content wrapper (counter-rotated to stay upright) */}
      <div className="relative z-10 flex items-center justify-center text-zinc-400 group-hover:text-white transition-colors duration-300">
        {React.Children.map(children, child => {
          if (React.isValidElement(child)) {
            // Apply conditional active coloring to icons if needed
            return React.cloneElement(child as React.ReactElement, {
              className: cn(child.props.className, active ? "text-[#00FFFF]" : "")
            });
          }
          return child;
        })}
      </div>
    </div>
  );
}
