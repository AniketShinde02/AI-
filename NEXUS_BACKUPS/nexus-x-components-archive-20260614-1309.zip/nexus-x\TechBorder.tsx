import React from 'react';
import { cn } from '@/lib/utils';

interface TechBorderProps {
  children: React.ReactNode;
  className?: string;
  glowColor?: string; // Optional custom color for the corners
}

export function TechBorder({ children, className, glowColor = "#6137FF" }: TechBorderProps) {
  return (
    <div className={cn("relative p-[1px] group", className)}>
      
      {/* Top Left Corner Bracket */}
      <div 
        className="absolute top-0 left-0 w-4 h-4 border-t-2 border-l-2 transition-colors duration-300 z-10"
        style={{ borderColor: "rgba(255,255,255,0.2)" }}
      >
        <div className="absolute top-0 left-0 w-full h-full opacity-0 group-hover:opacity-100 transition-opacity duration-300 shadow-[0_0_8px_currentColor]" style={{ color: glowColor }}></div>
      </div>
      
      {/* Top Right Corner Bracket */}
      <div 
        className="absolute top-0 right-0 w-4 h-4 border-t-2 border-r-2 transition-colors duration-300 z-10"
        style={{ borderColor: "rgba(255,255,255,0.2)" }}
      ></div>

      {/* Bottom Left Corner Bracket */}
      <div 
        className="absolute bottom-0 left-0 w-4 h-4 border-b-2 border-l-2 transition-colors duration-300 z-10"
        style={{ borderColor: "rgba(255,255,255,0.2)" }}
      ></div>

      {/* Bottom Right Corner Bracket */}
      <div 
        className="absolute bottom-0 right-0 w-4 h-4 border-b-2 border-r-2 transition-colors duration-300 z-10"
        style={{ borderColor: "rgba(255,255,255,0.2)" }}
      ></div>

      {/* Decorative Cyber Text Top */}
      <div className="absolute -top-[14px] right-4 text-[8px] font-mono tracking-widest text-white/30 hidden md:block">
        ..|..: ..|
      </div>

      {/* Main Content Area */}
      <div className="w-full h-full bg-[#06060c] border border-white/5 relative z-0">
        {children}
      </div>
    </div>
  );
}
